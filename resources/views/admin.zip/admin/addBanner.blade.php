
@include('admin.includes.header')

<div class="main_content_iner overly_inner ">
  <div class="container-fluid p-0 ">
    <div class="row justify-content-center">
      <div class="col-md-10">
        <div class="card p-4">
          <div class="card-header">
            <h4 class="f_s_30 f_w_700 text_white"><a href="javascript:history.back()" class="back_button" title="Back"><i class="fa fa-arrow-left"></i></a> <?php if(isset($banner)){ echo "Update"; }else{ echo "Add"; } ?> Banner</h4>
            <!-- <ol class="breadcrumb page_bradcam mb-0">
              <li class="breadcrumb-item"><a href="{{ url('admin/dashboard') }}">Dashboard</a></li>
              <li class="breadcrumb-item"><a href="{{ url('admin/banners') }}">Banners</a></li>
              <li class="breadcrumb-item active"><?php if(isset($banner)){ echo "Update"; }else{ echo "Add"; } ?> Banner</li>
            </ol> -->
          </div>
          <div class="card-body">
            <!-- @if(Session::has('message'))
            <p class="alert alert-success"><span style="font-weight: 600;"> Success !! </span>{{ Session::get('message') }}</p>
            @endif -->
            <p class="alert alert-success" style="display:none" id="msg"></p>
            
            <!-- <a href="#" class="white_btn3">Create Report</a>style="border: 1px solid #d7d7d7;" -->
          
            <!-- <h2 class="card-title text-center pb-5"><?php if(isset($banner)){ echo "Update"; }else{ echo "Add"; } ?> Banner</h2> -->
            <form id="formData" enctype="multipart/form-data">
              @csrf
              <div class="row mb-3">
                <div class="col-sm-2">
                  <label for="image" class="col-form-label">Upload Image</label>
                </div>
                <div class="col-sm-10">
                  <input type="file" name="image" class="form-control" id="image" onchange="previewFile(this,500,500);" <?php if(!isset($banner)){ echo "required"; } ?>>
                  <span class="text-danger"><b>Note : </b>Dimension 500px * 500px</span><br>
                  <img id="previewImg" src="<?php if(isset($banner)){ echo url("public/img/banners/".$banner->image);}else{ ?>../public/img/image-preview.png<?php } ?>" alt="Placeholder" width="100px">
                  <?php if(isset($banner)){ ?>
                  <input type="hidden" name="banner_id" id="banner_id" value="{{ $banner->id }}">
                  <input type="hidden" name="pre_image" value="{{ $banner->image }}">
                  <!-- <img src="{{ url('public/img/banners') }}/{{ $banner->image }}" alt="Banner Image" width="150" height="100"> -->
                  <?php }else{ ?>
                    <input type="hidden" name="banner_id" id="banner_id" value="">
                  <?php } ?>
                  <div class="text-danger" id="image_error"></div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-sm-2">
                <label for="name" class="col-form-label">Name</label>
                </div>
                <div class="col-sm-10">
                  <input type="text" name="name" class="form-control" placeholder="Name" id="name" value="<?php if(isset($banner)){ echo $banner->name; } ?>">
                  <div class="text-danger" id="name_error"></div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-sm-2">
                <label for="url" class="col-form-label">URL</label>
                </div>
                <div class="col-sm-10">
                  <input type="url" name="url" class="form-control" placeholder="URL" id="url" value="<?php if(isset($banner)){ echo $banner->url; } ?>">
                  <div class="text-danger" id="url_error"></div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-sm-2">
                  <label for="start_date" class="col-form-label">Start Date</label>
                </div>
                <div class="col-sm-10">
                  <input type="date" name="start_date" class="form-control" id="start_date" min="<?=date('Y-m-d')?>" value="<?php if(isset($banner)){ echo $banner->start_date; }else{ echo date('Y-m-d'); } ?>">
                  <div class="text-danger" id="start_date_error"></div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-sm-2">
                  <label for="end_date" class="col-form-label">Expiry Date</label>
                </div>
                <div class="col-sm-10">
                  <input type="date" name="end_date" class="form-control" id="end_date" min="<?=date('Y-m-d', strtotime(date('Y-m-d') . ' +1 day'))?>" value="<?php if(isset($banner)){ echo $banner->end_date; }else{ echo date('Y-m-d', strtotime(date('Y-m-d') . ' +1 day')); } ?>">
                  <div class="text-danger" id="end_date_error"></div>
                </div>
              </div>
              <div class="row">
                <div class="col-sm-12 text-center">
                  <button type="button" onclick="get_form_data()" class="btn btn-primary">Submit</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
  function get_form_data(){
    var banner_id = $('#banner_id').val();
    var name = $('#name').val();
    var image = $('#image').val();
    var url = $('#url').val();
    var start_date = new Date($('#start_date').val());
    var end_date = new Date($('#end_date').val());
    
    if(!name){
      $('#name_error').text("The name field is required."); 
      return false;     
    }
    if(banner_id==''){
      if(!image){
        $('#name_error').text("");
        $('#image_error').text("The image field is required.");
        return false;
      }
    }
    
    if(url!=''){
      if(!url.match(/^(?:(?:http|https|ftp):\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-._~:/?#[\]@!$&'()*+,;=%]+$/)){
        $('#url_error').text("Please enter valid URL");
        return false;
      }
    }
    if(new Date(start_date) > new Date(end_date)){
      $('#start_date_error').text("Start Date must be less then Expiry Date");
      return false;
    } 
    
    $('#url_error').text("");
    $('#start_date_error').text("");     
    $.ajax({  
      type:"POST",
      url:"{{url('admin/insertBanner')}}",
      data:new FormData( $("#formData")[0]),
      async : false,
      contentType : false,
      cache : false,
      processData: false,
      success:function(data)
      {
        if($.trim(data)=="update")
        { 
          $(window).scrollTop(0);
          $('#msg').show();
          $("#msg").html('<span style="font-weight: 600;"> Success !! </span> Banner updated successfully.');
          $('#image_error').html('');
          $('#name_error').html('');
          $('#start_date_error').html('');
          $('#end_date_error').html('');
          setTimeout(() => {
            window.location.href = "<?php echo url('admin/banners'); ?>";
          }, 5000);
        }
        else if($.trim(data)=="add")
        {
          $(window).scrollTop(0);
          $('#msg').show();
          $("#msg").html('<span style="font-weight: 600;"> Success !! </span> Banner added successfully.');
          $('#formData')[0].reset();
          $('#image_error').html('');
          $('#name_error').html('');
          $('#start_date_error').html('');
          $('#end_date_error').html('');
          setTimeout(() => {
            window.location.href = "<?php echo url('admin/banners'); ?>";
          }, 5000);
        }else{
          var obj=JSON.parse(data);
          if(obj.image){
            $('#image_error').html(obj.image);
            $('#name_error').html('');
            $('#start_date_error').html('');
            $('#end_date_error').html('');
          }else if(obj.name){
            $('#image_error').html('');
            $('#name_error').html(obj.name);
            $('#start_date_error').html('');
            $('#end_date_error').html('');
          }else if(obj.start_date){
            $('#image_error').html('');
            $('#name_error').html('');
            $('#start_date_error').html(obj.start_date);
            $('#end_date_error').html('');
          }else if(obj.end_date){
            $('#image_error').html('');
            $('#name_error').html('');
            $('#start_date_error').html('');
            $('#end_date_error').html(obj.end_date);
          }
        }
      }  
      
    });
 // }
  }
</script>

@include('admin.includes.footer')
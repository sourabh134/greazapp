@include('admin.includes.header')
<style>
    .nav-link {
        color: black;
    }
    .image-border .image {
        border: 1px solid #00000038;
    }

</style>
<div class="main_content_iner overly_inner ">
    <div class="container-fluid p-0 ">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card p-4">
                    <div class="card-header">
                        <h4 class="f_s_30 f_w_700 text_white"><a href="javascript:history.back()" class="back_button" title="Back"><i class="fa fa-arrow-left"></i></a> {{$title}}</h4>
                        <!-- <ol class="breadcrumb page_bradcam mb-0">
                <li class="breadcrumb-item"><a href="{{ url('admin/dashboard') }}">Dashboard</a></li>
                <li class="breadcrumb-item active">Car Detail</li>
                </ol> -->
                    </div>
                    <div class="card-body">
                        @if(Session::has('message'))
                        <p class="alert alert-success"><span style="font-weight: 600;"> Success !! </span>{{ Session::get('message') }}</p>
                        @endif
                        <!-- <a href="{{ url('admin/addBrand') }}" class="white_btn3">Create</a> -->
                        <!-- <button type="button" class="white_btn3" data-toggle="modal" data-target="#myModal"></button> -->
                        <!-- Button trigger modal -->
                        <div class="row">
                            @foreach($my_carlist as $value)
                            
                                <div class="col-md-4 image-border">
                                    <div class="image">
                                    <img src="<?php if($value->mycar_image!=''){ echo url("public/images/mycar/".$value->mycar_image);}else{ ?>../public/img/image-preview.png<?php } ?>" alt style="object-fit: fill; width: 100%;height:200px">
                                    </div>
                                    <div class="imagename text-center"><strong>{{$value->make}}</strong> <a href="{{url('/admin/mycarservice?key='.base64_encode($value->id))}}"><i class="fa fa-cog"></i>Service</a></div>
                                    
                                </div>
                            @endforeach

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



@include('admin.includes.footer')
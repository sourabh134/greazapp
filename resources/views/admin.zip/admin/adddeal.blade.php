
@include('admin.includes.header')

<div class="main_content_iner overly_inner ">
  <div class="container-fluid p-0 ">
    <div class="row justify-content-center">
      <div class="col-md-10">
        <div class="card p-4">
          <div class="card-header">
            <h4 class="f_s_30 f_w_700 text_white"><a href="javascript:history.back()" class="back_button" title="Back"><i class="fa fa-arrow-left"></i></a> <?php if(isset($data->id)){ echo "Update"; }else{ echo "Add"; } ?> {{$title}}</h4>
            <!-- <ol class="breadcrumb page_bradcam mb-0">
              <li class="breadcrumb-item"><a href="{{ url('admin/dashboard') }}">Dashboard</a></li>
              <li class="breadcrumb-item"><a href="{{ url('admin/dealList') }}">{{$title}}</a></li>
              <li class="breadcrumb-item active"><?php if(isset($data->id)){ echo "Update"; }else{ echo "Add"; } ?> {{$title}}</li>
            </ol> -->
          </div>
          <div class="card-body">
            <!-- @if(Session::has('message'))
            <p class="alert alert-success"><span style="font-weight: 600;"> Success !! </span>{{ Session::get('message') }}</p>
            @endif -->
            <!-- <p class="alert alert-success" style="display:none" id="msg"></p> -->
            
            <!-- <a href="#" class="white_btn3">Create Report</a>style="border: 1px solid #d7d7d7;" -->
            <!-- <h2 class="card-title text-center pb-5"><?php if(isset($data->id)){ echo "Update"; }else{ echo "Add"; } ?> Banner</h2> -->
            <form id="formData" enctype="multipart/form-data">
              @csrf
              <div class="row my-3">
                <div class="col-md-2">
                  <label for="name" class="col-form-label">Name</label>
                </div>
                <div class="col-sm-10">
                  <input type="text" name="name" class="form-control" placeholder="Name" id="name" value="<?php if(isset($data->id)){ echo $data->name; } ?>">
                  <div class="text-danger" id="name_error"></div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="discription" class="col-form-label">Discription</label>
                </div>
                <div class="col-sm-10">
                  <textarea class="form-control" name="discription" id="discription"><?php if(isset($data->id)){ echo $data->discription; } ?></textarea>
                  <div class="text-danger" id="discription_error"></div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="startDate" class="col-form-label">Start Date</label>
                </div>
                <div class="col-sm-10">
                  <input type="date" name="startDate" class="form-control" id="startDate" min="<?=date('Y-m-d')?>" value="<?php if(isset($data->id)){ echo $data->startDate; }else{ echo date('Y-m-d'); } ?>">
                  <div class="text-danger" id="startDate_error"></div>
                </div>
              </div>

              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="endDate" class="col-form-label">Expiry Date</label>
                </div>
                <div class="col-sm-10">
                  <input type="date" name="endDate" class="form-control" id="endDate" min="<?=date('Y-m-d', strtotime(date('Y-m-d') . ' +1 day'))?>" value="<?php if(isset($data->id)){ echo $data->endDate; }else{ echo date('Y-m-d', strtotime(date('Y-m-d') . ' +1 day')); } ?>">
                  <div class="text-danger" id="endDate_error"></div>
                </div>
              </div>
              
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="end_date" class="col-form-label">City</label>
                </div>
                <div class="col-sm-10">
                  <select class="js-example-basic-single form-select" name="city[]" id="city" multiple>
                    @foreach($city as $city_value)
                    <option <?php if(isset($data->id)){ foreach($dealdetail as $dval){ if($dval->cityID==$city_value->id){ echo "Selected"; } } }?> value="{{$city_value->id}}">{{$city_value->name}}</option>
                    @endforeach
                  </select>
                  <div class="text-danger" id="city_error"></div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="end_date" class="col-form-label">Deal Type</label>
                </div>
                <div class="col-sm-10">
                  <select class="form-select" id="dealtype" name="dealtype">
                    <option <?php if(isset($data->id)){if($data->dealType==1){ echo"Selected"; }} ?> value="1">Brand</option>
                    <option <?php if(isset($data->id)){if($data->dealType==2){ echo"Selected"; }} ?> value="2">Agent/Reseller</option>
                  </select>
                  <div class="text-danger" id="dealtype_error"></div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="end_date" class="col-form-label dealtypename"><?php if(isset($data->id)){ if($data->dealType==1){ echo"Brand"; }else{ echo"Agent"; } }else{ echo "Brand"; }  ?></label>
                </div>
                <div class="col-sm-10">
                  <?php if(isset($data->id)){
                    if($data->dealType==1){
                  ?>
                  <select class="form-select" name="dealtypeid" id="dealtypeid">
                    @foreach($brand as $bvalue)
                    <option <?php if(isset($data->id)){if($dealdetail[0]->dealTypeID==$bvalue->id){ echo"Selected"; }} ?> value="{{$bvalue->id}}">{{$bvalue->name}}</option>
                    @endforeach
                    
                  </select>
                  <?php }else{ ?>
                    <select class="form-select" name="dealtypeid" id="dealtypeid">
                    @foreach($agent as $avalue)
                    <option <?php if(isset($data->id)){if($dealdetail[0]->dealTypeID==$avalue->id){ echo"Selected"; }} ?> value="{{$avalue->id}}">{{$avalue->name}}</option>
                    @endforeach
                    
                  </select>

                  <?php } }else{ ?>

                  <select class="form-select" name="dealtypeid" id="dealtypeid">
                    @foreach($brand as $bvalue)
                    <option value="{{$bvalue->id}}">{{$bvalue->name}}</option>
                    @endforeach
                    
                  </select>
                  <?php } ?>
                  <div class="text-danger" id="dealtypeid_error"></div>
                </div>
              </div>
              <div class="row mb-4">
                <div class="col-md-2">
                  <label for="images" class="col-form-label">Image</label>
                </div>
                <div class="col-sm-10">
                  <input type="file" name="images"class="form-control files" placeholder="images" id="images" accept=".jpeg, .jpg, .png"  onchange="previewFiles(this,500,500);">
                  <span class="text-danger"><b>Note : </b>Dimension 500px * 500px</span><br>
                  <img id="previewImgs" src="<?php if(isset($data->id)){ echo url("public/images/".$data->image);}else{ ?>../public/img/image-preview.png<?php } ?>" alt="Placeholder" width="100px">
                  <div class="text-danger" id="image_error"></div>
                </div>
              </div>

              <div class="row">
                <div class="col-sm-12 text-center">
                <input type="hidden" class="id" name="id" id="id" value="@if(isset($data->id)) {{$data->id}} @endif">
                <button type="button" class="btn btn-primary submitdata">Submit</button>
                </div>
                <div class="alert alert-success text-center hide1"><span class="msg_success"></span></div>
                <div class="alert alert-danger text-center hide2"><span class="msg_danger"></span></div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
  $('#dealtype').change(function(){
    var id = $('#dealtype').val();
    var token = "<?=csrf_token()?>";
    if(id==1){
      $('.dealtypename').text("Brand");
    }else{
      $('.dealtypename').text("Agent / Reseller");
    }
    //alert(id);
    $.ajax({
      type:'POST',
      url:"{{url('/getdealtype')}}",
      data:{id:id,_token:token},
      success:function(res){        
          $('#dealtypeid').html(res)
      }
    })
  })
</script>
<script>
    $('.submitdata').click(function(){
      var name  = $('#name').val();
      var discription  = $('#discription').val();
      var startDate  = $('#startDate').val();
      var endDate  = $('#endDate').val();
      var city  = $('#city').val();
      var dealtype  = $('#dealtype').val();
      var dealtypeid  = $('#dealtypeid').val();
      var images  = $('#images').val();
      var id  = $('#id').val();
      if(!name){
        $('#name_error').text("The name field is required."); 
        return false;     
      }
      if(!discription){
        $('#name_error').text(""); 
        $('#discription_error').text("The discription field is required."); 
        return false;     
      }
      if(!startDate){
        $('#name_error').text(""); 
        $('#discription_error').text(""); 
        $('#startDate_error').text("The start Date field is required."); 
        return false;     
      }
      if(!endDate){
        $('#name_error').text(""); 
        $('#discription_error').text(""); 
        $('#startDate_error').text(""); 
        $('#endDate_error').text("The end Date field is required."); 
        return false;     
      }
      if(new Date(startDate) > new Date(endDate)){
        $('#startDate_error').text("Start Date must be less then Expiry Date");
        return false;
      }
      
      if(!dealtype){
        $('#name_error').text(""); 
        $('#discription_error').text(""); 
        $('#startDate_error').text(""); 
        $('#endDate_error').text(""); 
        $('#dealtype_error').text("The deal type field is required."); 
        return false;     
      }
      if(!dealtypeid){
        $('#name_error').text(""); 
        $('#discription_error').text(""); 
        $('#startDate_error').text(""); 
        $('#endDate_error').text(""); 
        $('#dealtype_error').text(""); 
        $('#dealtypeid_error').text("This field is required."); 
        return false;     
      }
      if(id==''){
        if(!images){
          $('#name_error').text(""); 
          $('#discription_error').text(""); 
          $('#startDate_error').text(""); 
          $('#endDate_error').text(""); 
          $('#dealtype_error').text(""); 
          $('#dealtypeid_error').text(""); 
          $('#image_error').text("The image field is required.");
          return false;
        }
      } 
      $.ajax({
          type:'POST',
          url:'{{url("/admin/insertdealtype")}}',
          data  :new FormData( $("#formData")[0] ),
          async   : false,
          cache   : false,
          contentType : false,
          processData : false,
          success:function(data){
            console.log(data);
            if($.trim(data)=="1"){
            $('.hide1').css('display','block');
            $('.msg_success').text("Sucessfully submitted");
            $(".alert-success").show('slow' , 'linear').delay(4000).fadeOut(function(){
                window.location.href="{{URL::to('/admin/dealList')}}";
            });

            }
            if($.trim(data)=="2"){
            $('.hide2').css('display','block');
            $('.msg_danger').text("Name already exist");
            $(".alert-danger").show('slow' , 'linear').delay(4000).fadeOut();

            }
          }
          
      });
       
    })
</script>

@include('admin.includes.footer')

@include('admin.includes.header')
<div class="main_content_iner overly_inner ">
  <div class="container-fluid p-0 ">
    <div class="row justify-content-center">
      <div class="col-md-10">
        <div class="card p-4">
          <div class="card-header">
            <h4 class="f_s_30 f_w_700 text_white"><a href="javascript:history.back()" class="back_button" title="Back"><i class="fa fa-arrow-left"></i></a> {{$title}} Form</h4>
            <!-- <ol class="breadcrumb page_bradcam mb-0">
              <li class="breadcrumb-item"><a href="{{ url('admin/dashboard') }}">Dashboard</a></li>
              <li class="breadcrumb-item"><a href="{{ url('admin/brands') }}">Agent</a></li>
              <li class="breadcrumb-item active">{{$title}} Form</li>
            </ol> -->
          </div>
          <div class="card-body">
            @if(Session::has('message'))
            <p class="alert alert-success"><span style="font-weight: 600;"> Success !! </span>{{ Session::get('message') }}</p>
            @endif
            <!-- <a href="#" class="white_btn3">Create Report</a> -->
     
            <!-- <h2 class="card-title text-center pb-5">Add Brand</h2> -->
            <form method="post" id="saveform" enctype="multipart/form-data">
              @csrf
              <div class="row my-3">
                <div class="col-md-2">
                  <label for="name" class="col-form-label">Name</label>
                </div>
                <div class="col-sm-10">
                  <input type="text" name="name" class="form-control name" placeholder="Name" id="name" value="@if(isset($data->id)) {{$data->name}} @endif" required>
                </div>
              </div>
              <div class="row mb-3 ui">
                <div class="col-md-2">
                  <label for="website" class="col-form-label">Brand</label>
                </div>
                <div class="col-sm-10">
                  <select name="brands[]" multiple="" class="js-example-basic-single form-select">
                    @foreach($brand as $brandvalue)
                    <?php
                    $brand = App\Models\Brand::where('id',$brandvalue->brandID)->first();
                    ?>
                    <option value="{{$brand->id}}" <?php if(isset($data->id)){ foreach($agentbrand as $agval){ if($agval->brandId==$brand->id){ echo"Selected"; }}}?>>{{$brand->name}}</option>
                    @endforeach
                  </select>
                </div>
              </div>
              <div class="row mb-3 ui">
                <div class="col-md-2">
                  <label for="servicetypeID" class="col-form-label">Service Type</label>
                </div>
                <div class="col-sm-10">
                  <select name="servicetypeID" class="form-select">
                    <option value="">Choose</option>
                    @foreach($servicetype as $value)
                    <option value="{{$value->id}}" <?php if(isset($data->id)){ if($value->id == $data->servicetypeID){ echo"selected"; }} ?>>{{$value->name}}</option>
                    @endforeach
                  </select>
                </div>
              </div>            
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="mobile" class="col-form-label">Mobile No.</label>
                </div>
                <div class="col-sm-10">
                  <input type="text" name="mobile" class="form-control" placeholder="Mobile No." id="mobile" value="@if(isset($data->id)) {{$data->contact}} @endif" required>               
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="youtube" class="col-form-label">Working Days</label>
                </div>
                <div class="col-sm-10">
                  <div class="row">
                    <div class="col-sm-6">
                      <select name="start_day" class="form-select">
                        <option <?php if(isset($data->id)){ if($data->start_day==1){ echo"selected"; }} ?> value="1">Monday</option>
                        <option <?php if(isset($data->id)){ if($data->start_day==2){ echo"selected"; }} ?> value="2">Tuesday</option>
                        <option <?php if(isset($data->id)){ if($data->start_day==3){ echo"selected"; }} ?> value="3">Wednesday</option>
                        <option <?php if(isset($data->id)){ if($data->start_day==4){ echo"selected"; }} ?> value="4">Thursday</option>
                        <option <?php if(isset($data->id)){ if($data->start_day==5){ echo"selected"; }} ?> value="5">Friday</option>
                        <option <?php if(isset($data->id)){ if($data->start_day==6){ echo"selected"; }} ?> value="6">Saturday</option>
                        <option <?php if(isset($data->id)){ if($data->start_day==7){ echo"selected"; }} ?> value="7">Sunday</option>
                      </select>
                    </div>
                    <div class="col-sm-6">
                      <select name="end_day" class="form-select">
                      <option <?php if(isset($data->id)){ if($data->end_day==1){ echo"selected"; }} ?> value="1">Monday</option>
                        <option <?php if(isset($data->id)){ if($data->end_day==2){ echo"selected"; }} ?> value="2">Tuesday</option>
                        <option <?php if(isset($data->id)){ if($data->end_day==3){ echo"selected"; }} ?> value="3">Wednesday</option>
                        <option <?php if(isset($data->id)){ if($data->end_day==4){ echo"selected"; }} ?> value="4">Thursday</option>
                        <option <?php if(isset($data->id)){ if($data->end_day==5){ echo"selected"; }} ?> value="5">Friday</option>
                        <option <?php if(isset($data->id)){ if($data->end_day==6){ echo"selected"; }} ?> value="6">Saturday</option>
                        <option <?php if(isset($data->id)){ if($data->end_day==7){ echo"selected"; }}else{ echo"selected"; } ?> value="7">Sunday</option>
                      </select>
                    </div> 
                  </div>             
                </div>
              </div> 
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="youtube" class="col-form-label">Working Hours</label>
                </div>
                <div class="col-sm-10">
                  <div class="row">
                    <div class="col-sm-6">
                      <input type="time" class="form-control" name="start_time" value="<?php if(isset($data->id)){ echo $data->start_time; } ?>">
                    </div>
                    <div class="col-sm-6">
                      <input type="time" class="form-control" name="end_time" value="<?php if(isset($data->id)){ echo $data->end_time; } ?>">
                    </div>
                  </div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="twitter" class="col-form-label">Country</label>
                </div>
                <div class="col-sm-10">
                  <select class="form-select" name="country" id="country">
                    <option value="">Choose</option>
                    @foreach($country as $countryvalue)
                    <option value="{{$countryvalue->id}}" <?php if(isset($data->id)){ if($countryvalue->id == $data->country){ echo"selected"; }} ?>>{{$countryvalue->name}}</option>
                    @endforeach
                  </select>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="linkedin" class="col-form-label">State</label>
                </div>
                <div class="col-sm-10">
                  <select class="form-select" name="state" id="state">
                    <option value="">Choose</option>
                    @if(isset($data->id))
                    @foreach($state as $value)
                    <option value="{{$value->id}}" <?php if(isset($data->id)){ if($value->id == $data->state){ echo"selected"; }} ?>>{{$value->name}}</option>
                    @endforeach
                    @endif
                  </select>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="facebook" class="col-form-label">City</label>
                </div>
                <div class="col-sm-10">
                  <select class="form-select" name="city" id="city">
                    <option value="">Choose</option>
                    @if(isset($data->id))
                    @foreach($city as $value)
                    <option value="{{$value->id}}" <?php if(isset($data->id)){ if($value->id == $data->city){ echo"selected"; }} ?>>{{$value->name}}</option>
                    @endforeach
                    @endif
                  </select>
                </div>
              </div>
              <div class="row mb-4">
                <div class="col-md-2">
                  <label for="instagram" class="col-form-label">Address</label>
                </div>
                <div class="col-sm-10">
                  <textarea class="form-control" name="address">@if(isset($data->id)) {{$data->address}} @endif</textarea>
                </div>
              </div>
              <div class="row">
                <div class="col-sm-12 text-center">
                  <input type="hidden" class="agentid" name="agentid" value="{{$agentid}}">
                  <input type="hidden" class="id" name="id" value="@if(isset($data->id)) {{$data->id}} @endif">
                  <button type="button" class="btn btn-primary submitdata">Submit</button>
                </div>
                <div class="alert alert-success text-center hide1"><span class="msg_success"></span></div>
                <div class="alert alert-danger text-center hide2"><span class="msg_danger"></span></div>
              </div>
            </form><!-- End Horizontal Form -->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
    $('.submitdata').click(function(){
        var name  = $('.name').val();
        var agentid = $('.agentid').val();       
        if(name==''){
            $('.name').css('border','1px solid red');
        }else{
            $('.name').css('border','');
            $.ajax({
                type:'POST',
                url:'{{url("/insert_branch")}}',
                data  :new FormData( $("#saveform")[0] ),
                async   : false,
                cache   : false,
                contentType : false,
                processData : false,
                success:function(data){
                  console.log(data);
                  if($.trim(data)=="1"){
                  $('.hide1').css('display','block');
                  $('.msg_success').text("Sucessfully submitted");
                  $(".alert-success").show('slow' , 'linear').delay(4000).fadeOut(function(){
                      window.location.href="{{URL::to('/admin/branch?key=')}}"+btoa(agentid);
                  });

                  }
                  if($.trim(data)=="2"){
                  $('.hide2').css('display','block');
                  $('.msg_danger').text("Name already exist");
                  $(".alert-danger").show('slow' , 'linear').delay(4000).fadeOut();

                  }
                }
                
            });
        }
    })
</script>
<script>
    $('#country').change(function(){
        var country_id = $(this).val();
        var token = "<?=csrf_token()?>";
        if(!country_id){
            $('#country').css("border","1px solid red");
        }else{
            $('#country').css("border","");
            $.ajax({
                type:'POST',
                url:"{{url('/getState')}}",
                data:{country_id:country_id,_token:token},
                success:function(res){
                    $('#state').html(res)

                }
            })
        }
    });

</script>
<script>
    $('#state').change(function(){
        var state_id = $(this).val();
        var token = "<?=csrf_token()?>";
        if(!state_id){
            $('#state').css("border","1px solid red");
        }else{
            $('#state').css("border","");
            $.ajax({
                type:'POST',
                url:"{{url('/getCity')}}",
                data:{state_id:state_id,_token:token},
                success:function(res){
                    $('#city').html(res)

                }
            })
        }
    });

</script>

@include('admin.includes.footer')
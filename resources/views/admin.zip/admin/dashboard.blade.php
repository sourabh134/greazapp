@include('admin.includes.header')
<style>

    .info-card {
        margin-bottom: 23px;
        border: 0;
    }

    .iconBorder {
        font-size: 90px;
        color: #f1f1f1;
    }

    .card-title {
        font-size: 18px;
        font-weight: 600;
        display: inline-block;
        color: #fff;
    }

    .valueWithName h3 {
        font-size: 32px;
        font-weight: 700;
        color: #fff;
    }

    .dash_card {
        height: 155px;
        background-color: #fff;
        border-radius: 5px;
        position: relative;
        margin: 15px 0;
    }

    .dash_card a {
        height: 30px;
        width: 30px;
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: 5px;
        color: #fff;
        float: right;
        padding-top: 5px;
    }

    .dash_card h5 {
        font-weight: 600;
    }

    .dash_card .items_icon {
        font-size: 52px;
        position: absolute;
        right: 68px;
        bottom: 20px;
    }

    /*---- for green color #1a9f53----- */
    .dash_green {
        border-left: 4px solid #1a9f53;
    }

    .dash_green a {
        background: #1a9f53;
    }

    .dash_green h5 {
        color: #1a9f53;
    }

    .dash_green .items_icon {
        color: #1a9f5336;
    }

    /*---- for purple color #be0ee1----- */
    .dash_purple {
        border-left: 4px solid #be0ee1;
    }

    .dash_purple a {
        background: #be0ee1;
    }

    .dash_purple h5 {
        color: #be0ee1;
    }

    .dash_purple .items_icon {
        color: #be0ee136;
    }

    /*---- for blue color #2b77e5----- */
    .dash_blue {
        border-left: 4px solid #2b77e5;
    }

    .dash_blue a {
        background: #2b77e5;
    }

    .dash_blue h5 {
        color: #2b77e5;
    }

    .dash_blue .items_icon {
        color: #2b77e536;
    }

    /*---- for yellow color #dd9718----- */
    .dash_yellow {
        border-left: 4px solid #dd9718;
    }

    .dash_yellow a {
        background: #dd9718;
    }

    .dash_yellow h5 {
        color: #dd9718;
    }

    .dash_yellow .items_icon {
        color: #dd971836;
    }

    /*---- for dark-blue color #001881----- */
    .dash_dark_blue {
        border-left: 4px solid #001881;
    }

    .dash_dark_blue a {
        background: #001881;
    }

    .dash_dark_blue h5 {
        color: #001881;
    }

    .dash_dark_blue .items_icon {
        color: #00188136;
    }

    /*---- for maroon color #670714----- */
    .dash_maroon {
        border-left: 4px solid #670714;
    }

    .dash_maroon a {
        background: #670714;
    }

    .dash_maroon h5 {
        color: #670714;
    }

    .dash_maroon .items_icon {
        color: #67071436;
    }

    /*---- for light-purple color #807af2----- */
    .dash_light_purple {
        border-left: 4px solid #807af2;
    }

    .dash_light_purple a {
        background: #807af2;
    }

    .dash_light_purple h5 {
        color: #807af2;
    }

    .dash_light_purple .items_icon {
        color: #807af236;
    }
</style>

<div class="main_content_iner overly_inner ">
    <div class="container-fluid p-0 ">
        <div class="row">
            <div class="col-12">
                <div class="page_title_box d-flex align-items-center justify-content-between">
                    <div class="page_title_left">
                        <h4 class="f_s_30 f_w_700 text_white">Dashboard</h4>
                    </div>
                    <!-- <a href="#" class="white_btn3">Create Report</a> -->
                    @if(Session::has('message'))
                    <p class="alert alert-success"><span style="font-weight: 600;"> Success !! </span>{{ Session::get('message') }}</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
    <section class="dashboard">
        <div class="row">
            <div class="col-xxl-3 col-md-3">
                <div class="dash_card dash_green">
                    <div class="p-4">
                        <h5>Total Cars</h5>
                        <h3>{{$car}}</h3>
                        <a href="{{ url('admin/brands') }}"> <i class="fi fi-rr-angle-small-right"></i> </a>
                    </div>
                    <i class="fi fi-bs-taxi items_icon"></i>
                </div>
            </div>
            <div class="col-xxl-3 col-md-3">
                <div class="dash_card dash_purple">
                    <div class="p-4">
                        <h5>Total Brands</h5>
                        <h3>{{$brand}}</h3>
                        <a href="{{ url('admin/brands') }}"> <i class="fi fi-rr-angle-small-right"></i> </a>
                    </div>
                    <i class="fi fi-bs-taxi items_icon"></i>
                </div>
            </div>
            <div class="col-xxl-3 col-md-3">
                <div class="dash_card dash_blue">
                    <div class="p-4">
                        <h5>Total Categories</h5>
                        <h3>{{$category}}</h3>
                        <a href="{{ url('admin/category') }}"> <i class="fi fi-rr-angle-small-right"></i> </a>
                    </div>
                    <i class="fi fi-ss-category items_icon"></i>
                </div>
            </div>
            <div class="col-xxl-3 col-md-3">
                <div class="dash_card dash_yellow">
                    <div class="p-4">
                        <h5>Total Service Types</h5>
                        <h3>{{$service}}</h3>
                        <a href="{{ url('admin/serviceType') }}"> <i class="fi fi-rr-angle-small-right"></i> </a>
                    </div>
                    <i class="fi fi-br-tools items_icon"></i>
                </div>
            </div>
            <div class="col-xxl-3 col-md-3">
                <div class="dash_card dash_dark_blue">
                    <div class="p-4">
                        <h5>Total Agents</h5>
                        <h3>{{$agent}}</h3>
                        <a href="{{ url('admin/agent') }}"> <i class="fi fi-rr-angle-small-right"></i> </a>
                    </div>
                    <i class="fi fi-ss-user-headset items_icon"></i>
                </div>
            </div>
            <div class="col-xxl-3 col-md-3">
                <div class="dash_card dash_light_purple">
                    <div class="p-4">
                        <h5>Total Deals</h5>
                        <h3>{{$deals}}</h3>
                        <a href="{{ url('admin/dealList') }}"> <i class="fi fi-rr-angle-small-right"></i> </a>
                    </div>
                    <i class="fi fi-sr-handshake items_icon"></i>
                </div>
            </div>
            <div class="col-xxl-3 col-md-3">
                <div class="dash_card dash_maroon">
                    <div class="p-4">
                        <h5>Total User</h5>
                        <h3>{{$user}}</h3>
                        <a href="{{ url('admin/userList') }}"> <i class="fi fi-rr-angle-small-right"></i> </a>
                    </div>
                    <i class="fi fi-sr-user items_icon"></i>
                </div>
            </div>
        </div>
    </section>
</div>

@include('admin.includes.footer')
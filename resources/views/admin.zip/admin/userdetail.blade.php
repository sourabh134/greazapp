@include('admin.includes.header')
<style>
    .nav-link {
        color: black;
    }
    .image-border .image {
        border: 1px solid #00000038;
    }

</style>
<div class="main_content_iner overly_inner ">
    <div class="container-fluid p-0 ">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card p-4">
                    <div class="card-header">
                        <h4 class="f_s_30 f_w_700 text_white"><a href="javascript:history.back()" class="back_button" title="Back"><i class="fa fa-arrow-left"></i></a> {{$data->name}} Detail</h4>
                        <!-- <ol class="breadcrumb page_bradcam mb-0">
                <li class="breadcrumb-item"><a href="{{ url('admin/dashboard') }}">Dashboard</a></li>
                <li class="breadcrumb-item active">Car Detail</li>
                </ol> -->
                    </div>
                    <div class="card-body">
                        @if(Session::has('message'))
                        <p class="alert alert-success"><span style="font-weight: 600;"> Success !! </span>{{ Session::get('message') }}</p>
                        @endif
                        <!-- <a href="{{ url('admin/addBrand') }}" class="white_btn3">Create</a> -->
                        <!-- <button type="button" class="white_btn3" data-toggle="modal" data-target="#myModal"></button> -->
                        <!-- Button trigger modal -->
                        <nav>
                            <div class="nav nav-tabs mb-3" id="nav-tab" role="tablist">
                                <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Profile</button>
                                <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Favorite Lists</button>
                                <!-- <button class="nav-link" id="nav-contact-tab" data-bs-toggle="tab" data-bs-target="#nav-contact" type="button" role="tab" aria-controls="nav-contact" aria-selected="false">Comment</button> -->
                            </div>
                        </nav>
                        <div class="tab-content p-3 border" id="nav-tabContent">
                            <div class="tab-pane fade active show" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                                <div class="QA_table ">
                                    <table class="table p-0">
                                        <tr>
                                            <td><strong>Name</strong></td>
                                            <td>{{$data->name}}</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Gender</strong></td>
                                            <td><?php if($data->gender==1){ echo "Male"; }else if($data->gender==2){ echo "Female"; }else{ echo "Other"; } ?></td>
                                        </tr>
                                        <tr>
                                            <td><strong>Email</strong></td>
                                            <td>{{$data->email}}</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Mobile Number</strong></td>
                                            <td>{{$data->mobile_number}}</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Profile Image</strong></td>
                                            <td><img class="img-fluid" src="<?php if($data->profileImage!=''){ echo url("public/images/".$data->profileImage);}else{ ?>../public/img/image-preview.png<?php } ?>" alt width="100" height="100"></td>
                                        </tr>
                                        <tr>
                                            <td><strong>Driver License</strong></td>
                                            <td>
                                                <a href="<?php if($data->DriverLicense!=''){ ?>{{url('public/images/'.$data->DriverLicense)}}<?php }else{ echo '#!'; }?>"><i class="fa fa-file-pdf" style="font-size: 25px;color: #b70909;"></i>
                                            </td>
                                        </tr>

                                        
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">                                
                                <div class="row">
                                @foreach($favorite as $fev)
                                <?php
                                $carimage = App\Models\CarImage::where('vehicleID',$fev->vehicleID);
                                if($carimage->count()==0){
                                    $car_image = "";
                                }else{
                                    $car_image = $carimage->first()->image;
                                }
                                ?>
                                    <div class="col-md-4 image-border">
                                        <div class="image">
                                        <img src="<?php if($car_image!=''){ echo url("public/images/car/".$car_image);}else{ ?>../public/img/image-preview.png<?php } ?>" alt style="object-fit: fill; width: 100%;height:200px">
                                        </div>
                                        <div class="imagename text-center"><strong>{{App\Models\Vehicle::find($fev->vehicleID)->name}}</strong></div>
                                    </div>
                                @endforeach

                                </div>
                            </div>
                            <!-- <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
                                <div class="QA_table ">
                                    <table class="table p-0">
                                        <tr>
                                            <td><strong>Fuel Tank Capacity</strong></td>
                                            <td></td>
                                        </tr>
                                        
                                    </table>
                                </div>
                            </div>                            -->
                        </div>
                        <!-- tab -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(".deleteimg").click(function() {
        var id = $(this).data('id');
        var token = "<?= csrf_token() ?>";
        if (confirm("Are you sure want to delete this?")) {
            $.ajax({
                type: 'POST',
                url: '{{url("/admin/deleteimg")}}',
                data: {
                    id: id,
                    _token: token
                },
                success: function(data) {
                    location.reload();
                }

            });
        }
    })
</script>
<script>
    $('.flexSwitchCheckChecked').click(function() {
        var id = $(this).data('id');
        var token = "<?= csrf_token() ?>";
        if ($(this).is(':checked')) {
            var status = 1;
        } else {
            var status = 0;
        }
        if (confirm("Are you sure want to change this status?")) {
            $.ajax({
                type: 'POST',
                url: '{{url("/admin/change_car_status")}}',
                data: {
                    id: id,
                    _token: token,
                    status: status
                },
                success: function(data) {
                    location.reload();
                }

            });
        }
    })
</script>
<script>
    $('.flexSwitchCheckCheckedpopular').click(function() {
        var id = $(this).data('id');
        var token = "<?= csrf_token() ?>";
        if ($(this).is(':checked')) {
            var status = 1;
        } else {
            var status = 0;
        }
        if (confirm("Are you sure want to add this in popular list?")) {
            $.ajax({
                type: 'POST',
                url: '{{url("/admin/add_popular_car")}}',
                data: {
                    id: id,
                    _token: token,
                    status: status
                },
                success: function(data) {
                    location.reload();
                }

            });
        }
    })
</script>

@include('admin.includes.footer')
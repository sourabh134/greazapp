@include('admin.includes.header')

<div class="main_content_iner overly_inner ">
  <div class="container-fluid p-0 ">
    <div class="row justify-content-center">
      <div class="col-md-7">
        <div class="card p-4">
          <div class="card-header">
            <h4 class="f_s_30 f_w_700 text_white"><a href="javascript:history.back()" class="back_button" title="Back"><i class="fa fa-arrow-left"></i></a> {{$title}} Form</h4>
            <!-- <ol class="breadcrumb page_bradcam mb-0">
              <li class="breadcrumb-item"><a href="{{ url('admin/dashboard') }}">Dashboard</a></li>
              <li class="breadcrumb-item"><a href="{{ url('admin/serviceType') }}">{{$title}}</a></li>
              <li class="breadcrumb-item active">{{$title}} Form</li>
            </ol> -->
          </div>
          @if(Session::has('message'))
          <p class="alert alert-success"><span style="font-weight: 600;"> Success !! </span>{{ Session::get('message') }}</p>
          @endif
          <!-- <a href="#" class="white_btn3">Create Report</a> -->
          <div class="card-body">
            <!-- <h2 class="card-title text-center pb-5">Add Brand</h2> -->
            <form method="post" id="saveform" enctype="multipart/form-data">
              @csrf
              <div class="row mb-3">
                <div class="col-sm-2">
                  <label for="image" class="col-form-label">Image</label>
                </div>
                <div class="col-sm-10">
                  <input type="file" name="image" class="form-control" id="image" onchange="previewFile(this,40,40);" <?php if(!isset($data->id)){ echo "required"; } ?>>
                  <span class="text-danger"><b>Note : </b>Dimension 40px * 40px</span><br>
                  <img id="previewImg" src="<?php if(isset($data->id)){ echo url("public/images/".$data->image);}else{ ?>../public/img/image-preview.png<?php } ?>" alt="Placeholder" width="40px">
                  <div class="text-danger" id="image_error"></div>
                </div>
              </div>
              <div class="row my-3">
                <div class="col-sm-2 ">
                  <label for="name" class="col-form-label">Name</label>
                </div>
                <div class="col-sm-10">
                  <input type="text" name="name" class="form-control name" placeholder="Name" id="name" value="@if(isset($data->id)) {{$data->name}} @endif" required>
                  <div class="text-danger" id="name_error"></div>
                </div>
              </div>
              <div class="row">
                <div class="col-sm-12">
                  <div class="text-center mt-3">
                    <input type="hidden" class="id" name="id" value="@if(isset($data->id)) {{$data->id}} @endif">
                    <button type="button" class="btn btn-primary submitdata">Submit</button>
                  </div>
                </div>
                <div class="alert alert-success text-center hide1"><span class="msg_success"></span></div>
                <div class="alert alert-danger text-center hide2"><span class="msg_danger"></span></div>
              </div>
            </form><!-- End Horizontal Form -->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
  $('.submitdata').click(function() {
    var name = $('.name').val();
    var image = $('#image').val();
    var id = $('.id').val();
    if (name == '') {
      //$('.name').css('border', '1px solid red');
      $('#name_error').text("The name field is required."); 
      return false;
    }
    if(id ==''){
      if (!image) {
        $('#name_error').text("");
        $('#image_error').text("The image field is required.");
        return false;
      }
    }
      //$('.name').css('border', '');
      $.ajax({
        type: 'POST',
        url: '{{url("/admin/insert_serviceType")}}',
        data: new FormData($("#saveform")[0]),
        async: false,
        cache: false,
        contentType: false,
        processData: false,
        success: function(data) {
          console.log(data);
          if ($.trim(data) == "1") {
            $('.hide1').css('display', 'block');
            $('.msg_success').text("Sucessfully submitted");
            $(".alert-success").show('slow', 'linear').delay(4000).fadeOut(function() {
              window.location.href = "{{URL::to('/admin/serviceType')}}";
            });

          }
          if ($.trim(data) == "2") {
            $('.hide2').css('display', 'block');
            $('.msg_danger').text("Name already exist");
            $(".alert-danger").show('slow', 'linear').delay(4000).fadeOut();

          }
          if ($.trim(data) == "3") {           
            $('#image_error').text("Invalid image dimensions must be 40px X 40px");

          }
          
        }

      });
   
  })
</script>

@include('admin.includes.footer')
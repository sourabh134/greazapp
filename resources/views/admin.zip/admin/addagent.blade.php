
@include('admin.includes.header')
<div class="main_content_iner overly_inner ">
  <div class="container-fluid p-0 ">
    <div class="row justify-content-center">
      <div class="col-md-10">
        <div class="card p-4">
          <div class="card-header">
            <h4 class="f_s_30 f_w_700 text_white"><a href="javascript:history.back()" class="back_button" title="Back"><i class="fa fa-arrow-left"></i></a>Add Agent / Reseller</h4>
            <!-- <ol class="breadcrumb page_bradcam mb-0">
              <li class="breadcrumb-item"><a href="{{ url('admin/dashboard') }}">Dashboard</a></li>
              <li class="breadcrumb-item"><a href="{{ url('admin/brands') }}">Agent</a></li>
              <li class="breadcrumb-item active">Add Agent</li>
            </ol> -->
          </div>
          <div class="card-body">
            @if(Session::has('message'))
            <p class="alert alert-success"><span style="font-weight: 600;"> Success !! </span>{{ Session::get('message') }}</p>
            @endif
            <!-- <a href="#" class="white_btn3">Create Report</a> -->
            <!-- <h2 class="card-title text-center pb-5">Add Brand</h2> -->
            <form method="post" id="saveform" enctype="multipart/form-data">
              @csrf
              <div class="row my-3">
                <div class="col-md-2">
                  <label for="name" class="col-form-label">Name</label>
                </div>
                <div class="col-sm-10">
                  <input type="text" name="name" class="form-control name" placeholder="Name" id="name" value="@if(isset($data->id)) {{$data->name}} @endif" required>
                  <div class="text-danger" id="name_error"></div>
                </div>
              </div>            
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="logo" class="col-form-label">Logo</label>
                </div>
                <div class="col-sm-10">
                  <input type="file" name="image" class="form-control file" placeholder="Logo" id="logo" accept=".jpeg, .jpg, .png"  onchange="previewFile(this,100,100);">
                  <span class="text-danger"><b>Note : </b>Dimension 100px * 100px</span><br>
                  <img id="previewImg" src="<?php if(isset($data->id)){ echo url("public/images/".$data->logo);}else{ ?>../public/img/image-preview.png<?php } ?>" alt="Placeholder" width="100px">
                  <div class="text-danger" id="logo_error"></div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="imagess" class="col-form-label">Image</label>
                </div>
                <div class="col-sm-10">
                  <input type="file" name="images"class="form-control files" placeholder="images" id="imagess" accept=".jpeg, .jpg, .png"  onchange="previewFiless(this,500,500);">
                  <span class="text-danger"><b>Note : </b>Dimension 500px * 500px</span><br>
                  <img id="previewImgs" src="<?php if(isset($data->id)){ echo url("public/images/".$data->images);}else{ ?>../public/img/image-preview.png<?php } ?>" alt="Placeholder" width="100px">
                  <div class="text-danger" id="imagess_error"></div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="info" class="col-form-label">Description</label>
                </div>
                <div class="col-sm-10">
                  <textarea name="info" id="info" cols="30" rows="5" class="form-control" placeholder="Description">@if(isset($data->id)) {{$data->description}} @endif</textarea>
                </div>
              </div>
              <div class="row mb-3 ui">
                <div class="col-md-2">
                  <label for="website" class="col-form-label">Brand</label>
                </div>
                <div class="col-sm-10">
                <select name="brands[]" multiple="" id="brands" class="js-example-basic-single form-select">
                  @foreach($brand as $brandvalue)
                  <option value="{{$brandvalue->id}}" <?php if(isset($data->id)){ foreach($agentbrand as $agval){ if($agval->brandID==$brandvalue->id){ echo"Selected"; }}}?>>{{$brandvalue->name}}</option>
                  @endforeach
                </select>
                <div class="text-danger" id="brands_error"></div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="email" class="col-form-label">Email</label>
                </div>
                <div class="col-sm-10">
                  <input type="text" name="email" class="form-control" placeholder="Email" id="email" value="@if(isset($data->id)) {{$data->email}} @endif" required>               
                  <div class="text-danger" id="email_error"></div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="mobile" class="col-form-label">Mobile No.</label>
                </div>
                <div class="col-sm-10">
                  <input type="text" name="mobile" class="form-control" placeholder="Mobile No." id="mobile" value="@if(isset($data->id)) {{$data->contact}} @endif" required>               
                  <div class="text-danger" id="mobile_error"></div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="youtube" class="col-form-label">Youtube</label>
                </div>
                <div class="col-sm-10">
                  <input type="text" name="youtube" class="form-control" placeholder="Youtube" id="youtube" value="@if(isset($data->id)) {{$data->youtube}} @endif" required>               
                  <div class="text-danger" id="youtube_error"></div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="twitter" class="col-form-label">Twitter</label>
                </div>
                <div class="col-sm-10">
                  <input type="text" name="twitter" class="form-control" placeholder="Twitter" id="twitter" value="@if(isset($data->id)) {{$data->twitter}} @endif" required>               
                  <div class="text-danger" id="twitter_error"></div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="linkedin" class="col-form-label">Linkedin</label>
                </div>
                <div class="col-sm-10">
                  <input type="text" name="linkedin" class="form-control" placeholder="Linkedin" id="linkedin" value="@if(isset($data->id)) {{$data->linkedin}} @endif" required>               
                  <div class="text-danger" id="linkedin_error"></div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="facebook" class="col-form-label">Facebook</label>
                </div>
                <div class="col-sm-10">
                  <input type="text" name="facebook" class="form-control" placeholder="Facebook" id="facebook" value="@if(isset($data->id)) {{$data->facebook}} @endif" required>               
                  <div class="text-danger" id="facebook_error"></div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="instagram" class="col-form-label">Instagram</label>
                </div>
                <div class="col-sm-10">
                  <input type="text" name="instagram" class="form-control" placeholder="Instagram" id="instagram" value="@if(isset($data->id)) {{$data->instagram}} @endif" required>               
                  <div class="text-danger" id="instagram_error"></div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-2">
                  <label for="snapchat" class="col-form-label">Snapchat</label>
                </div>
                <div class="col-sm-10">
                  <input type="text" name="snapchat" class="form-control" placeholder="Snapchat" id="snapchat" value="@if(isset($data->id)) {{$data->snap_chat}} @endif" required>               
                  <div class="text-danger" id="snapchat_error"></div>
                </div>
              </div>
              <div class="row align-items-center mb-3">
                <div class="col-md-2">
                  <label for="instagram" class="col-form-label">Type</label>
                </div>
                <div class="col-sm-10">
                  <input type="radio" id="agent" name="type" value="1" <?php if(isset($data->id)){ if($data->type==1){echo "checked"; }}else{ ?>checked<?php } ?> >
                  <label for="agent">Agent</label>
                  <input type="radio" id="reseller" name="type" value="2" <?php if(isset($data->id)){ if($data->type==2){echo "checked"; }} ?>>
                  <label for="reseller">Reseller</label>             
                </div>
              </div>
              
              <div class="row mt-3">
                <div class="col-sm-12 text-center">
                  <input type="hidden" class="id" name="id" id="id" value="@if(isset($data->id)) {{$data->id}} @endif">
                  <button type="button" class="btn btn-primary submitdata">Submit</button>
                </div>
                <div class="alert alert-success text-center hide1"><span class="msg_success"></span></div>
                <div class="alert alert-danger text-center hide2"><span class="msg_danger"></span></div>
              </div>
            </form><!-- End Horizontal Form -->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
    $('.submitdata').click(function(){
        var name  = $('#name').val();        
        var logo  = $('#logo').val();        
        var imagess  = $('#imagess').val();      
        var brands  = $('#brands').val();   
        var email  = $('#email').val();   
        var mobile  = $('#mobile').val();   
        var youtube  = $('#youtube').val();   
        var twitter  = $('#twitter').val();   
        var linkedin  = $('#linkedin').val();   
        var facebook  = $('#facebook').val();   
        var instagram  = $('#instagram').val();
        var snapchat  = $('#snapchat').val();
        var id  = $('#id').val();
        alert(brands);
        if(!name){
          $('#name_error').text("The name field is required."); 
          return false;     
        }
        if(id==''){
          if(!logo){
            $('#name_error').text("");
            $('#logo_error').text("The logo field is required.");
            return false;
          }
          if(!imagess){
            $('#name_error').text("");
            $('#logo_error').text("");
            $('#imagess_error').text("The image field is required.");
            return false;
          }
        }
        if(brands==''){
          $('#name_error').text("");
          $('#logo_error').text("");
          $('#imagess_error').text("");
          $('#brands_error').text("The brand field is required.");
          return false;
        }
        if(!email){
          $('#name_error').text("");
          $('#logo_error').text("");
          $('#imagess_error').text("");
          $('#brands_error').text("");
          $('#email_error').text("The email field is required.");
          return false;
        }
        if(!email.match(/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/)){
          $('#name_error').text("");
          $('#logo_error').text("");
          $('#imagess_error').text("");
          $('#brands_error').text("");
          $('#email_error').text("Please enter valid email");
          return false;
        }
        if(!mobile){
          $('#name_error').text("");
          $('#logo_error').text("");
          $('#imagess_error').text("");
          $('#brands_error').text("");
          $('#email_error').text("");
          $('#mobile_error').text("The mobile number field is required.");
          return false;
        }
        if(!mobile.match(/^[0-9]{10}$/)){
          $('#name_error').text("");
          $('#logo_error').text("");
          $('#imagess_error').text("");
          $('#brands_error').text("");
          $('#email_error').text("");
          $('#mobile_error').text("Please enter valid number");
          return false;
        }
        if(youtube!=''){
          if(!youtube.match(/^(?:(?:http|https|ftp):\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-._~:/?#[\]@!$&'()*+,;=%]+$/)){
            $('#youtube_error').text("Please enter valid URL");
            return false;
          }
        }
        if(twitter!=''){
          if(!twitter.match(/^(?:(?:http|https|ftp):\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-._~:/?#[\]@!$&'()*+,;=%]+$/)){
            $('#twitter_error').text("Please enter valid URL");
            return false;
          }
        }
        if(linkedin!=''){
          if(!linkedin.match(/^(?:(?:http|https|ftp):\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-._~:/?#[\]@!$&'()*+,;=%]+$/)){
            $('#linkedin_error').text("Please enter valid URL");
            return false;
          }
        }
        if(facebook!=''){
          if(!facebook.match(/^(?:(?:http|https|ftp):\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-._~:/?#[\]@!$&'()*+,;=%]+$/)){
            $('#facebook_error').text("Please enter valid URL");
            return false;
          }
        }
        if(instagram!=''){
          if(!instagram.match(/^(?:(?:http|https|ftp):\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-._~:/?#[\]@!$&'()*+,;=%]+$/)){
            $('#instagram_error').text("Please enter valid URL");
            return false;
          }
        }
        if(snapchat!=''){
          if(!snapchat.match(/^(?:(?:http|https|ftp):\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-._~:/?#[\]@!$&'()*+,;=%]+$/)){
            $('#snapchat_error').text("Please enter valid URL");
            return false;
          }
        }
        $.ajax({
            type:'POST',
            url:'{{url("/admin/insert_agent")}}',
            data  :new FormData( $("#saveform")[0] ),
            async   : false,
            cache   : false,
            contentType : false,
            processData : false,
            success:function(data){
              console.log(data);
              if($.trim(data)=="1"){
              $('.hide1').css('display','block');
              $('.msg_success').text("Sucessfully submitted");
              $(".alert-success").show('slow' , 'linear').delay(4000).fadeOut(function(){
                  window.location.href="{{URL::to('/admin/agent')}}";
              });

              }
              if($.trim(data)=="2"){
              $('.hide2').css('display','block');
              $('.msg_danger').text("Name already exist");
              $(".alert-danger").show('slow' , 'linear').delay(4000).fadeOut();

              }
            }
            
        });       
    })
</script>


@include('admin.includes.footer')
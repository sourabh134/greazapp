@include('admin.includes.header')
<style>
    .col-md-5.border.myser {
        padding: 20px;
        margin: 0px 5px 5px 0px;
    }
    .serviceicon{
        padding-top: 14px;
        font-size: 20px;
    }

</style>
<div class="main_content_iner overly_inner ">
    <div class="container-fluid p-0 ">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card p-4">
                    <div class="card-header">
                        <h4 class="f_s_30 f_w_700 text_white"><a href="javascript:history.back()" class="back_button" title="Back"><i class="fa fa-arrow-left"></i></a> {{$title}}</h4>
                        <!-- <ol class="breadcrumb page_bradcam mb-0">
                <li class="breadcrumb-item"><a href="{{ url('admin/dashboard') }}">Dashboard</a></li>
                <li class="breadcrumb-item active">Car Detail</li>
                </ol> -->
                    </div>
                    <div class="card-body">
                        @if(Session::has('message'))
                        <p class="alert alert-success"><span style="font-weight: 600;"> Success !! </span>{{ Session::get('message') }}</p>
                        @endif
                        <!-- <a href="{{ url('admin/addBrand') }}" class="white_btn3">Create</a> -->
                        <!-- <button type="button" class="white_btn3" data-toggle="modal" data-target="#myModal"></button> -->
                        <!-- Button trigger modal -->
                        <div class="row">
                            @foreach($MycarService as $value) 
                            <?php
                            if($value->service != ''){
                                $serv = explode(",",$value->service);
                                $sername = "";
                                foreach($serv as $se){
                                    $ser = App\Models\MycarServiceTask::find($se)->name;
                                    $sername = $sername.','.$sername;;
                                }
                                $service_name = $sername;
                            }else{
                                $service_name = "";
                            }
                            ?>                           
                                <div class="col-md-5 border myser">
                                    <div class="row">
                                        <div class="col-md-1 serviceicon">
                                            <?php if($value->service_type==1){ ?>
                                            <i class="fa fa-cog"></i>
                                            <?php }else{ ?>
                                                <i class="fa fa-dashboard"></i>
                                            <?php } ?>
                                        </div>
                                        <div class="col-md-10">
                                            <p><strong>{{$value->serviceDate}}</strong> <span>{{$value->serviceCenter}}</span> <span><?php if($value->totalcost!=''){ ?>{{$value->totalcost}} USD<?php } ?></span></p>
                                            <p><strong>ODO:{{$value->odometer}}</strong> <span>{{$service_name}}</span></p>
                                        </div>
                                    </div>
                                </div>
                            @endforeach

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



@include('admin.includes.footer')